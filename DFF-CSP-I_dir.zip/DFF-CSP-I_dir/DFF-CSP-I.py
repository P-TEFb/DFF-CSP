#! /usr/bin/python
#Author: Mrutyunjaya Parida,supervised by David Price

import glob,os,sys

try:
    from joblib import Parallel, delayed

except ImportError:
    print "Please install the joblib module via this command: python -m pip install joblib";
    print "This command will work if the pip module is pre-installed.";
    print "To install pip please try this URL: httss://pip.pypa.io/en/stable/installing/";
    print "Please follow 2 steps, first download get-pip.py and then secondly, please run : python get-pip.py or python get-pip.py --user, depending on sudo access";
    print "Now, please run this command: python -m pip install joblib";
    print "Incase, you do not have sudo access, please try this:  python -m pip install --user joblib";
    print "Once the joblib module is installed successfully, you may rerun the tsrFinderv2 again";
    sys.exit();
        
currentDirectory=os.getcwd();
PROGRAM=currentDirectory+'/DFF-CSP.py';
PROGRAM2=currentDirectory+'/FRAGMENT-CENTER.py';
RMF=currentDirectory+'/README_TSR.txt';

f='';STEPSIZE='';MINSEQDEPTH='';chromsize='';

def readme(RF):
    COMMAND='cat '+RF;
    os.system(COMMAND);
    sys.exit();
    
def runtsrfinder(IF):
    os.system(IF);
    
try:
    if isinstance(sys.argv[1],str) and os.path.isfile(sys.argv[1]):
        FILE=open(sys.argv[1].strip(),'r');
        PROGRAM=PROGRAM;
        for i in FILE:
            DATA=i.strip().split('\t');
            if len(DATA)==6:
                pass;
            else:
                print "This file is not formatted properly. Fields have to be tab separated."
                print "Format example: "+"chr1    28672   28729   K00274:88:HJ7WLBBXX:8:2125:6725:19548   255     +";
                sys.exit();
                
        COMMAND='python '+PROGRAM2+' '+sys.argv[1].strip();
        os.system(COMMAND);
        CHECK=[c for c in sys.argv[2:-1] if c.isdigit()];
        if len(CHECK)==2:
            STEPSIZE=int(sys.argv[2].strip());#TSR window size
            MINSEQDEPTH=int(sys.argv[3].strip());#MIN SEQ DEPTH
            if isinstance(sys.argv[-1],str) and os.path.isfile(sys.argv[-1]):
                chromsize=sys.argv[-1].strip();
                C1="python "+PROGRAM+' '+sys.argv[1].strip().replace('.bed','-FC.bed')+' '+\
                    ' '.join(sys.argv[2:]).strip();
                num_cores=1;
                results = Parallel(n_jobs=num_cores)(delayed(runtsrfinder)(inpf) for inpf in [C1]);
                COMMAND=['rm '+mr.strip().replace('.bed','-FC_TSR_STEP-2_OUTPUT.txt') for mr in [sys.argv[1].strip()]];
                results = Parallel(n_jobs=num_cores)(delayed(runtsrfinder)(inpf) for inpf in COMMAND);
                COMMAND=['rm '+mr.strip().replace('.bed','-FC_TSR_STEP-3_OUTPUT.txt') for mr in [sys.argv[1].strip()]];
                results = Parallel(n_jobs=num_cores)(delayed(runtsrfinder)(inpf) for inpf in COMMAND);
                COMMAND=['mv '+sys.argv[1].strip().replace('.bed','-FC_TSR_STEP-4_OUTPUT.txt')+\
                         ' '+sys.argv[1].strip().replace('.bed','-TSR.tab')];
                results = Parallel(n_jobs=num_cores)(delayed(runtsrfinder)(inpf) for inpf in COMMAND);
                TABFILE=open(sys.argv[1].strip().replace('.bed','-TSR.tab'),'r').readlines();
                TMP=open(sys.argv[1].strip().replace('.bed','-TSR.tmp'),'w');
                STR='\t'.join(['chr','tsrL','tsrR','tsrReadLensum','strength','strand']+\
                              ['TSSL','TSSR','maxTSS','TSSstrength','avgTSS','maxTSS-avgTSS','stdevAvgTSS']).strip();
                TMP.write(STR+'\n');
                for strtab in TABFILE:
                    TMP.write('\t'.join(strtab.strip().split('\t')[:8]+\
                                        [strtab.strip().split('\t')[7]]+\
                                        strtab.strip().split('\t')[8:]).strip()+'\n');
                TMP.close();
                COMMAND=['mv '+sys.argv[1].strip().replace('.bed','-TSR.tmp')+\
                         ' '+sys.argv[1].strip().replace('.bed','-TSR.tab')];
                results = Parallel(n_jobs=num_cores)(delayed(runtsrfinder)(inpc) for inpc in COMMAND);
                COMMAND=['rm '+sys.argv[1].strip().replace('.bed','-FC.bed')];
                results = Parallel(n_jobs=num_cores)(delayed(runtsrfinder)(inpc) for inpc in COMMAND);
        else:
            readme(RMF);

except IndexError:
    readme(RMF);
    
