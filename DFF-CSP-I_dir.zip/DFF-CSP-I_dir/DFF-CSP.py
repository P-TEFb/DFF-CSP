#! /usr/bin/python

#####################################
#Author: Mrutyunjaya Parida,David Price Lab, UIOWA
#####################################

from __future__ import division
from collections import defaultdict
import sys,math,time,os

start = time.time();

#STEP1:READ THE BED FILE AND CONSIDER STRAND SPECIFICITY IN THE NEXT STEP
f=open(sys.argv[1].strip(),'r');

#Provide a chrom size text file
chromsize=open(sys.argv[-1],'r').readlines();
CHRSIZE=[chrsz.strip().split('\t') for chrsz in chromsize];
DDFW=defaultdict(lambda: defaultdict(list));
DDRV=defaultdict(lambda: defaultdict(list));
DDCHRSIZE=defaultdict(int);

for chrsz in CHRSIZE:
    DDCHRSIZE[chrsz[0].strip()]=int(chrsz[1].strip());

len(DDCHRSIZE.keys());

#STEP2:GENERATE TSS, TSS+1,SUM OF READ LENGTH,READ COUNT,STRAND
def COUNT(LIST,STRAND):
    RETURNL=[];
    DDNPLUSL=defaultdict(int);
    DDNPLUSRL=defaultdict(int);
    if STRAND=='+':
        for lin in LIST:
            if int(lin[-1])%2==0:#even 2 centers
                DDNPLUSL[int(lin[1].strip())]+=0.5;
                DDNPLUSL[int(lin[1].strip())+1]+=0.5;
                DDNPLUSRL[int(lin[1].strip())]+=int(lin[-1]);
                DDNPLUSRL[int(lin[1].strip())+1]+=int(lin[-1]);
            elif int(lin[-1])%2!=0:#odd 1 center
                DDNPLUSL[int(lin[1].strip())]+=1;
                DDNPLUSRL[int(lin[1].strip())]+=int(lin[-1]);
            
        STARTS=DDNPLUSL.keys();
        STARTS.sort(key=int);
        for s in STARTS:
            RETURNL.append([s,s+1,DDNPLUSRL[s],DDNPLUSL[s]]);
    else:
        for lin in LIST:
            if int(lin[-1])%2==0:#even 2 centers
                DDNPLUSL[int(lin[2].strip())]+=0.5;
                DDNPLUSL[int(lin[2].strip())-1]+=0.5;
                DDNPLUSRL[int(lin[2].strip())]+=int(lin[-1]);
                DDNPLUSRL[int(lin[2].strip())-1]+=int(lin[-1]);
            elif int(lin[-1])%2!=0:#odd 1 center
                DDNPLUSL[int(lin[1].strip())]+=1;
                DDNPLUSRL[int(lin[1].strip())]+=int(lin[-1]);
                
        STARTS=DDNPLUSL.keys();
        STARTS.sort(key=int);
        for s in STARTS:
            RETURNL.append([s-1,s,DDNPLUSRL[s],DDNPLUSL[s]]);
        
    return RETURNL;

id_to_process = '1';
lines_to_process = []
OFILE=open(sys.argv[1].strip().replace('.bed','_TSR_STEP-2_OUTPUT.txt'),'w');

while True:
   raw_line = f.readline()
   # check whether we're at eof       
   if not raw_line:
        break
   # get line
   line = raw_line.rstrip().split("\t")
   id = line[0].strip();
   strand = line[-2].strip();
   # same id
   if id == id_to_process.strip():
      lines_to_process.append(line)
   # a new id is coming
   else:
       # do something with your lines
       if len(lines_to_process)>0:
           for eidl in COUNT(lines_to_process,strand):
               OFILE.write('\t'.join([id_to_process]+[repr(x).strip() for x in eidl]+[strand]).strip()+'\n');
       # now proceed with next id
       id_to_process = id.strip();
       lines_to_process = [line]

for idll in COUNT(lines_to_process,strand):
    OFILE.write('\t'.join([id_to_process]+[repr(y).strip() for y in idll]+[strand]).strip()+'\n');
       
f.close();
OFILE.close();

#STEP3: TSR INPUT FORMATTING
FILE=open(sys.argv[1].strip().replace('.bed','_TSR_STEP-2_OUTPUT.txt'),'r').readlines();
DDDATA=defaultdict(list);
STEPSIZE=int(sys.argv[2].strip());#TSR window size
MINSEQDEPTH=int(sys.argv[3].strip());#MIN SEQ DEPTH
OFILE=open(sys.argv[1].strip().replace('.bed','_TSR_STEP-3_OUTPUT.txt'),'w');

for f in FILE:
    DATA=f.strip().split('\t');
    DDDATA[DATA[0].strip()].append(DATA);
    
for key in DDDATA.keys():
    CHR=key.strip();
    DATACHR=[[int(c[1]),c] for c in DDDATA[CHR]];
    DATACHR.sort(key=lambda x:x[0]);
    DDTSR=defaultdict(list);
    RANGEKEYS=set();
    for edc in  DATACHR:
        RANGE=[[r,r+STEPSIZE] for r in range((edc[0]+1)-STEPSIZE,edc[0]+1)];
        for ran in RANGE:
            DDTSR[CHR+':'+repr(ran[0]).strip()+'-'+repr(ran[1]).strip()].append([edc[1][1].strip(),edc[1][2].strip(),int(edc[1][3]),float(edc[1][4]),edc[1][5].strip()]);
            RANGEKEYS.add(repr(ran[0]).strip()+'-'+repr(ran[1]).strip());
    RANGEKEYS=[[int(kr) for kr in rk.strip().split('-')] for rk in RANGEKEYS if not rk.strip().startswith('-')];        
    RANGEKEYS.sort(key=lambda x:x[0]);
    CHR,RANGEKEYS;
    for rkey in RANGEKEYS:
        RLSUM=sum([rlsum[2] for rlsum in DDTSR[CHR+':'+repr(rkey[0]).strip()+'-'+repr(rkey[1]).strip()]]);
        RCOVSUM=sum([rcsum[3] for rcsum in DDTSR[CHR+':'+repr(rkey[0]).strip()+'-'+repr(rkey[1]).strip()]]);
        STRAND=DDTSR[CHR+':'+repr(rkey[0]).strip()+'-'+repr(rkey[1]).strip()][0][4].strip();
        MAXTSS=[[mtss[3],int(mtss[0]),mtss] for mtss in DDTSR[CHR+':'+repr(rkey[0]).strip()+'-'+repr(rkey[1]).strip()]];
        MAXTSS.sort(key=lambda x:x[0],reverse=True);#SORT BY READ COVERAGE
        MAXRC=[mts for mts in MAXTSS if mts[0]>=MAXTSS[0][0]];
        MAXRC.sort(key=lambda x:x[1]);#SORT BY COORDINATE TO GET THE FIRST MAX TSS BP
        TSRPOS=[int(tsrpos[1])*tsrpos[3] for tsrpos in DDTSR[CHR+':'+repr(rkey[0]).strip()+'-'+repr(rkey[1]).strip()]];
        if RCOVSUM>=MINSEQDEPTH:
            AVGPOS=sum(TSRPOS)/RCOVSUM;
            stdevAvgPos=math.sqrt(sum([((int(epos[1])-AVGPOS)**2)*epos[3] for epos in DDTSR[CHR+':'+repr(rkey[0]).strip()+'-'+repr(rkey[1]).strip()]])/RCOVSUM);
            OFILE.write('\t'.join([CHR,repr(rkey[0]).strip(),repr(rkey[1]).strip(),repr(RLSUM).strip(),repr(RCOVSUM).strip(),STRAND]+MAXRC[0][2][0:2]+[repr(MAXRC[0][2][3]).strip(),repr(AVGPOS),repr(int(MAXRC[0][2][1])-AVGPOS).strip(),repr(stdevAvgPos).strip()]).strip()+'\n');
        else:
            pass;
OFILE.close();

#STEP4: TSR FINDING ALGORITHM
fi=open(sys.argv[1].strip().replace('.bed','_TSR_STEP-3_OUTPUT.txt'),'r');

id_to_process = '1';
lines_to_process = []
OFILE=open(sys.argv[1].strip().replace('.bed','_TSR_STEP-4_OUTPUT.txt'),'w');
STEP=int(sys.argv[2].strip());

def TSRF(LIST,STEPSIZE):
    k=0;TSR=[];len(LIST);MAX=[];
    while repr(k)!=repr(len(LIST)):
        DDL=defaultdict(list);
        for f in LIST:
            DATA=f
            TMP=DATA[0].strip()+':'+DATA[1].strip()+'-'+DATA[2].strip();
            DDL[TMP]=DATA;
        REMOVE=set();
        try:
            MAX=LIST[0];
        except IndexError:
            pass;
        for l in LIST[1:]:
            if len(range(max(int(l[1]),int(MAX[1])),min(int(l[2]),int(MAX[2]))))>0 and float(l[4])>float(MAX[4]):
                MAX=l;
            elif len(range(max(int(l[1]),int(MAX[1])),min(int(l[2]),int(MAX[2]))))<1:
                MAX;
                TSR.append(MAX);
                MAX=l;
        TSR.append(MAX);
        REMOVE=[rn[0].strip()+':'+'-'.join([repr(nr),repr(nr+STEPSIZE)]).strip() for rn in TSR for nr in range((int(rn[1])+1)-STEPSIZE,int(rn[2]))];
        k=len(LIST);
        LIST=[[int(DDL[ls][1]),DDL[ls]] for ls in set(DDL.keys()).difference(REMOVE)];
        LIST.sort(key=lambda x:x[0]);
        LIST=[sl[1] for sl in LIST];
    if MAX:
        TSR.append(MAX);
        TSR=set(['\t'.join(ts).strip() for ts in TSR]);
        TSR=[[int(srrt.strip().split('\t')[1]),srrt.strip()] for srrt in list(TSR)];
        TSR.sort(key=lambda x:x[0]);
        TSR=[w[1].strip() for w in TSR];
    return TSR;
    
while True:
   raw_line = fi.readline()
   # check whether we're at eof
   if not raw_line:
        break
   # get line
   line = raw_line.rstrip().split("\t")
   id = line[0].strip();
   strand = line[-1].strip();
   # same id
   if id == id_to_process.strip():
      lines_to_process.append(line)
   # a new id is coming
   else:
       # do something with your lines
       if len(lines_to_process)>0:
           for tsrf in TSRF(lines_to_process,STEP):
               CHECKTSRBUNDRY=tsrf.strip().split('\t');
               if DDCHRSIZE[CHECKTSRBUNDRY[0].strip()]>0 and int(CHECKTSRBUNDRY[2])<=DDCHRSIZE[CHECKTSRBUNDRY[0].strip()]:
                  OFILE.write(tsrf.strip()+'\n');
       # now proceed with next id
       id_to_process = id.strip();
       lines_to_process = [line];

for tsrl in TSRF(lines_to_process,STEP):
    CHECKTSRBUNDRY=tsrl.strip().split('\t');
    if DDCHRSIZE[CHECKTSRBUNDRY[0].strip()]>0 and int(CHECKTSRBUNDRY[2])<=DDCHRSIZE[CHECKTSRBUNDRY[0].strip()]:
       OFILE.write(tsrl.strip()+'\n');
OFILE.close();

end = time.time();
