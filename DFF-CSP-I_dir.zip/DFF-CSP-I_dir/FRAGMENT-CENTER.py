import sys

FILE=open(sys.argv[1].strip(),'r').readlines();
OFILE=open(sys.argv[1].strip().replace('.bed','-FC.bed'),'w');

for f in FILE:
    DATA=f.strip().split('\t');
    FSIZE=int(DATA[2])-int(DATA[1]);
    if (FSIZE%2==0):
        OFILE.write('\t'.join([DATA[0]]+\
                              [repr((int(DATA[1])+int(float(FSIZE)/2))-1),repr((int(DATA[1])+int(float(FSIZE)/2))+1)]+\
                              DATA[3:]+[repr(FSIZE)]).strip()+'\n');
    else:
        OFILE.write('\t'.join([DATA[0]]+\
                              [repr((int(DATA[1])+int(float(FSIZE)/2))),repr((int(DATA[1])+int(float(FSIZE)/2))+1)]+\
                              DATA[3:]+[repr(FSIZE)]).strip()+'\n');
OFILE.close();

        
        
